import React, { useState, useEffect } from "react";

/*
Town of Shadows - App.jsx (single-file main app)
Text-only narration version packaged for Netlify (Vite + React).

This file is the main application component. It is intentionally kept
self-contained and uses plain CSS (no Tailwind required) so the app
can run immediately after `npm install` and `npm run dev`.

Instructions:
1. npm install
2. npm run dev
3. Build: npm run build
4. Deploy the `dist/` folder to Netlify

This prototype focuses on core gameplay, chat-style narration,
5x4 grid UI, AI fillers, role assignment per your v3.5 rules, and
text-only narration.
*/

const CONFIG = {
  TOTAL_PLAYERS: 20,
  FACTION_COUNTS: { town: 8, mafia: 5, cult: 4, neutrals: 3 },
};

const ROLE_POOL = {
  town: [
    "Detective","Sheriff","Investigator","Lookout","Tracker","Bodyguard",
    "Doctor","Jailor","Cupid","Mayor","Vigilante","Escort","Medium","Soldier","Gossip"
  ],
  mafia: [
    "Godfather","Mafioso","Janitor","Spy","Beastman","Consort","Blackmailer","Framer","Disguiser","Forger"
  ],
  cult: ["Cult Leader","Fanatic","Infiltrator","Prophet","High Priest","Acolyte"],
  neutrals: ["Jester","Executioner","Serial Killer","Arsonist","Survivor","Amnesiac","Witch","Guardian Angel"],
};

function shuffle(array) {
  let a = array.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function sample(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function buildMafiaRoles() {
  const roles = ["Godfather","Mafioso"];
  const others = ROLE_POOL.mafia.filter((r) => r !== "Godfather" && r !== "Mafioso");
  roles.push(sample(others));
  while (roles.length < CONFIG.FACTION_COUNTS.mafia) {
    const pick = Math.random() < 0.5 ? "Mafioso" : sample(others);
    roles.push(pick);
  }
  return shuffle(roles);
}
function buildCultRoles() {
  const roles = ["Cult Leader","Fanatic"];
  const pool = ROLE_POOL.cult.filter((r)=> r !== "Cult Leader" && r !== "Fanatic");
  while (roles.length < CONFIG.FACTION_COUNTS.cult) roles.push(sample(pool));
  return shuffle(roles);
}
function buildTownRoles() {
  return shuffle(ROLE_POOL.town).slice(0, CONFIG.FACTION_COUNTS.town);
}
function buildNeutrals() {
  return shuffle(ROLE_POOL.neutrals).slice(0, CONFIG.FACTION_COUNTS.neutrals);
}
function buildFullRoles() {
  const mafia = buildMafiaRoles();
  const cult = buildCultRoles();
  const town = buildTownRoles();
  const neutrals = buildNeutrals();
  const all = [...town,...mafia,...cult,...neutrals];
  while (all.length < CONFIG.TOTAL_PLAYERS) all.push(sample(ROLE_POOL.town));
  return shuffle(all);
}
function roleToFaction(role) {
  if (ROLE_POOL.town.includes(role)) return "Town";
  if (ROLE_POOL.mafia.includes(role)) return "Mafia";
  if (ROLE_POOL.cult.includes(role)) return "Cult";
  if (ROLE_POOL.neutrals.includes(role)) return "Neutral";
  return "Unknown";
}

export default function App(){
  const [players, setPlayers] = useState([]);
  const [log, setLog] = useState([]);
  const [phase, setPhase] = useState("lobby");
  const [youId, setYouId] = useState(1);
  const [yourPrivateOpen, setYourPrivateOpen] = useState(false);
  const [dayCount, setDayCount] = useState(0);

  useEffect(()=> startNewGame(), []);

  function appendLog(t){
    setLog(l=>[...l, t]);
  }

  function startNewGame(){
    const roles = buildFullRoles();
    const pls = [];
    for(let i=1;i<=CONFIG.TOTAL_PLAYERS;i++){
      const role = roles[i-1];
      pls.push({id:i, name:`Player ${i}`, role, faction: roleToFaction(role), alive:true, revealed:false, doused:false});
    }
    setPlayers(pls);
    setPhase("day");
    setDayCount(1);
    setLog([]);
    appendLog("Game started — Town of Shadows (text narration)");
    appendLog("System: Click 'View Your Role' to privately see your role. The narrator will guide the match.");
  }

  function factionSymbol(f){
    if(f==="Town") return "🏠";
    if(f==="Mafia") return "💀";
    if(f==="Cult") return "🔮";
    if(f==="Neutral") return "⚙️";
    return "❓";
  }

  function revealPrivateRole(){ setYourPrivateOpen(true); }

  function killPlayer(id, reason){
    setPlayers(ps => ps.map(p => p.id===id? {...p, alive:false, revealed:true} : p));
    appendLog(`System: Player ${id} died. (${reason})`);
  }
  function convertToCult(id){
    setPlayers(ps => ps.map(p => p.id===id? {...p, faction:"Cult", role:"Acolyte"}:p));
    appendLog(`System: Player ${id} has been converted to Cult.`);
  }

  async function processNight(){
    appendLog("System: Night actions resolving (simplified engine).");
    const alive = players.filter(p=>p.alive);
    const mafiaAlive = alive.filter(p=>p.faction==="Mafia");
    if(mafiaAlive.length>0){
      const target = sample(alive.filter(p=>p.faction!=="Mafia"));
      if(target){ killPlayer(target.id, "Mafia kill"); }
    }
    const cultAlive = alive.filter(p=>p.faction==="Cult");
    if(cultAlive.length>0){
      const convertible = alive.filter(p=>p.faction!=="Mafia" && p.faction!=="Cult");
      if(convertible.length>0 && Math.random()<0.15){
        const v = sample(convertible);
        convertToCult(v.id);
      }
    }
    setTimeout(()=>{ setPhase("day"); setDayCount(dc=>dc+1); appendLog(`System: Day ${dayCount+1} dawns.`); }, 700);
  }

  function nextPhase(){
    if(phase==="day"){
      appendLog(`System: Night ${dayCount} falls.`);
      setPhase("night");
      processNight();
    } else {
      setPhase("day");
      setDayCount(dc=>dc+1);
      appendLog(`System: Day ${dayCount+1} dawns.`);
    }
  }

  function renderBox(p){
    const content = p.alive ? (p.revealed ? `${factionSymbol(p.faction)} ${p.role}` : "❓") : `☠️ ${p.role}`;
    return (
      <div key={p.id} style={{width:140,height:72,border:"1px solid #ccc",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",margin:6,background:"#fff"}}>
        <div style={{fontWeight:600}}>{p.id}</div>
        <div style={{fontSize:12,marginTop:6}}>{content}</div>
      </div>
    );
  }

  const you = players.find(p=>p.id===youId);

  return (
    <div style={{fontFamily:"Arial,Helvetica,sans-serif",padding:18,background:"#f5f5f7",minHeight:"100vh"}}>
      <div style={{maxWidth:1100,margin:"0 auto"}}>
        <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <h1>Town of Shadows</h1>
          <div>
            <button onClick={startNewGame} style={{marginRight:8}}>New Game</button>
            <button onClick={revealPrivateRole}>View Your Role</button>
          </div>
        </header>

        <main style={{display:"flex",gap:12}}>
          <section style={{flex:2}}>
            <div style={{display:"flex",flexWrap:"wrap",maxWidth:760}}>
              {players.map(p=>renderBox(p))}
            </div>

            <div style={{marginTop:12,background:"#fff",padding:10,height:220,overflow:"auto",border:"1px solid #ddd"}}>
              {log.map((l,i)=>(<div key={i} style={{padding:"6px 0",fontSize:13}}>{l}</div>))}
            </div>

            <div style={{marginTop:8,display:"flex",gap:8,alignItems:"center"}}>
              <button onClick={nextPhase}>Advance Phase</button>
              <div>Phase: {phase} | Day: {dayCount}</div>
            </div>
          </section>

          <aside style={{width:300}}>
            <div style={{background:"#fff",padding:10,border:"1px solid #ddd"}}>
              <h3>Your Info</h3>
              <p>Player: {you?you.id:"—"}</p>
              <p>Role: {you?you.role:"—"}</p>
              <p>Faction: {you?you.faction:"—"}</p>
              <div style={{marginTop:8}}>
                <h4>Quick Actions (demo)</h4>
                <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                  <button onClick={()=>appendLog("System: Demo action - nothing happened.")}>Demo</button>
                </div>
              </div>
              <div style={{marginTop:10,fontSize:13}}>Netlify: Deploy build folder. Tutorial popups & role guidance included.</div>
            </div>
          </aside>
        </main>

        {yourPrivateOpen && you && (
          <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.45)",display:"flex",alignItems:"center",justifyContent:"center"}}>
            <div style={{background:"#fff",padding:18,width:420,borderRadius:6}}>
              <h2>Your Role (Private)</h2>
              <p><strong>Player {you.id}</strong></p>
              <p style={{fontWeight:600}}>{you.role} — {you.faction}</p>
              <div style={{marginTop:8,fontSize:13}}>
                <strong>Note:</strong> This prototype uses text-only narration. The system will explain rules in chat as the match begins.
              </div>
              <div style={{marginTop:12,textAlign:"right"}}>
                <button onClick={()=>setYourPrivateOpen(false)}>Close</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
